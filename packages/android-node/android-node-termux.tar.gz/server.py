#!/usr/bin/env python3
"""
Android Node Server for Alphabot
Provides Android automation tools via uiautomator2
"""

import asyncio
import json
import logging
from typing import Dict, Any
import uiautomator2 as u2
from aiohttp import web
import websockets

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AndroidNode:
    def __init__(self, device_serial: str = None):
        """Initialize Android Node with device connection"""
        self.device = u2.connect(device_serial)
        logger.info(f"Connected to device: {self.device.info}")
        
    async def handle_tool_call(self, tool: str, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle tool call from alphabot"""
        try:
            if tool == "android_tap":
                return await self.tap(args)
            elif tool == "android_swipe":
                return await self.swipe(args)
            elif tool == "android_input":
                return await self.input_text(args)
            elif tool == "android_screenshot":
                return await self.screenshot(args)
            elif tool == "android_get_ui_tree":
                return await self.get_ui_tree(args)
            else:
                return {"error": f"Unknown tool: {tool}"}
        except Exception as e:
            logger.error(f"Tool call error: {e}")
            return {"error": str(e)}
    
    async def tap(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Tap at coordinates or on UI element"""
        if "x" in args and "y" in args:
            self.device.click(args["x"], args["y"])
            return {"success": True, "action": "tap", "x": args["x"], "y": args["y"]}
        elif "text" in args:
            self.device(text=args["text"]).click()
            return {"success": True, "action": "tap", "text": args["text"]}
        elif "resourceId" in args:
            self.device(resourceId=args["resourceId"]).click()
            return {"success": True, "action": "tap", "resourceId": args["resourceId"]}
        else:
            return {"error": "Missing tap target (x/y or text or resourceId)"}
    
    async def swipe(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Swipe gesture"""
        fx, fy = args.get("fx", 0), args.get("fy", 0)
        tx, ty = args.get("tx", 0), args.get("ty", 0)
        duration = args.get("duration", 0.5)
        
        self.device.swipe(fx, fy, tx, ty, duration=duration)
        return {"success": True, "action": "swipe", "from": [fx, fy], "to": [tx, ty]}
    
    async def input_text(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Input text"""
        text = args.get("text", "")
        self.device.send_keys(text)
        return {"success": True, "action": "input", "text": text}
    
    async def screenshot(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Capture screenshot"""
        output_path = args.get("path", "/tmp/screenshot.png")
        self.device.screenshot(output_path)
        return {"success": True, "action": "screenshot", "path": output_path}
    
    async def get_ui_tree(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Get UI hierarchy"""
        xml = self.device.dump_hierarchy()
        return {"success": True, "action": "get_ui_tree", "xml": xml}


async def websocket_handler(websocket, path, node: AndroidNode):
    """Handle WebSocket connection from alphabot"""
    logger.info(f"WebSocket connected: {path}")
    
    try:
        async for message in websocket:
            data = json.loads(message)
            tool = data.get("tool")
            args = data.get("args", {})
            
            result = await node.handle_tool_call(tool, args)
            await websocket.send(json.dumps(result))
    except websockets.exceptions.ConnectionClosed:
        logger.info("WebSocket connection closed")


async def http_handler(request):
    """Handle HTTP tool calls"""
    data = await request.json()
    tool = data.get("tool")
    args = data.get("args", {})
    
    node = request.app["node"]
    result = await node.handle_tool_call(tool, args)
    
    return web.json_response(result)


async def main():
    """Start Android Node server"""
    # Initialize Android Node
    node = AndroidNode()
    
    # Start HTTP server
    app = web.Application()
    app["node"] = node
    app.router.add_post("/tool", http_handler)
    
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", 8765)
    await site.start()
    
    logger.info("Android Node server started on http://0.0.0.0:8765")
    logger.info("WebSocket server started on ws://0.0.0.0:8766")
    
    # Start WebSocket server
    async with websockets.serve(
        lambda ws, path: websocket_handler(ws, path, node),
        "0.0.0.0",
        8766
    ):
        await asyncio.Future()  # Run forever


if __name__ == "__main__":
    asyncio.run(main())
