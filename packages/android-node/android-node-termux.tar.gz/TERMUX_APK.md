# Termux APK 打包指南

## 方案说明

使用 Termux 将 Python Android Node 打包为 APK。

## 打包步骤

### 1. 安装 Termux 和依赖

在 Android 设备上：
1. 安装 Termux APK
2. 安装 Termux:API APK
3. 在 Termux 中安装 Python 和依赖

```bash
pkg update
pkg install python python-pip
pip install uiautomator2 websockets aiohttp pillow
```

### 2. 部署 Android Node

```bash
# 创建目录
mkdir -p ~/android-node
cd ~/android-node

# 复制文件（从 PC 通过 adb push 或其他方式）
# server.py, requirements.txt 等
```

### 3. 创建启动脚本

创建 `start.sh`:
```bash
#!/data/data/com.termux/files/usr/bin/bash
cd ~/android-node
python server.py
```

### 4. 设置开机自启（可选）

使用 Termux:Boot：
```bash
pkg install termux-services
mkdir -p ~/.termux/boot
cp start.sh ~/.termux/boot/
chmod +x ~/.termux/boot/start.sh
```

## 简化方案：使用 Termux Tasker 插件

更简单的方式是使用 Termux:Tasker 插件配合 Tasker 应用：

1. 安装 Termux:Tasker
2. 创建 Tasker 任务启动 Android Node
3. 设置开机自动运行

## 注意事项

- Termux 需要保持后台运行
- 建议使用 Termux:Boot 实现开机自启
- 需要授予 Termux 存储权限
- 首次运行需要初始化 uiautomator2

## 安装说明

1. 安装 Termux.apk
2. 安装 Termux-API.apk（如需要）
3. 打开 Termux，运行安装脚本
4. 启动 Android Node server

## 下载链接

- Termux: https://f-droid.org/packages/com.termux/
- Termux:API: https://f-droid.org/packages/com.termux.api/
- Termux:Boot: https://f-droid.org/packages/com.termux.boot/
