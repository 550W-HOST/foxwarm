# Android Node 部署文档

## 前置要求

### Android 设备
- Android 5.0+ (API 21+)
- 开启 USB 调试
- 开启无障碍服务权限

### PC 端
- Python 3.8+
- ADB (Android Debug Bridge)

## 安装步骤

### 1. 安装依赖

```bash
cd packages/android-node
pip install -r requirements.txt
```

### 2. 连接 Android 设备

**USB 连接：**
```bash
# 检查设备连接
adb devices

# 应该看到类似输出：
# List of devices attached
# XXXXXX    device
```

**WiFi 连接（可选）：**
```bash
# 先通过 USB 连接，然后：
adb tcpip 5555
adb connect <设备IP>:5555
```

### 3. 初始化 uiautomator2

```bash
# 首次使用需要初始化（会在设备上安装 ATX-agent）
python -m uiautomator2 init
```

### 4. 启动 Android Node Server

```bash
python server.py
```

服务启动后会监听：
- HTTP: `http://0.0.0.0:8765`
- WebSocket: `ws://0.0.0.0:8766`

## 测试验证

```bash
# 运行测试脚本
python test.py
```

测试脚本会验证所有核心功能：
- ✅ Screenshot
- ✅ Get UI Tree
- ✅ Tap
- ✅ Swipe
- ✅ Input

## 集成到 Alphabot

### 1. 注册为 Node

在 alphabot 配置中添加 Android Node：

```yaml
nodes:
  android:
    type: remote
    url: http://<Android设备IP>:8765
    tools:
      - android_tap
      - android_swipe
      - android_input
      - android_screenshot
      - android_get_ui_tree
```

### 2. 使用示例

```javascript
// 在 alphabot 中调用 Android tools
await tools.android_tap({ x: 500, y: 500 });
await tools.android_screenshot({ path: "/tmp/screen.png" });
await tools.android_input({ text: "Hello" });
```

## 故障排查

### 设备连接失败
```bash
# 检查 ADB 连接
adb devices

# 重启 ADB server
adb kill-server
adb start-server
```

### uiautomator2 初始化失败
```bash
# 手动安装 ATX-agent
python -m uiautomator2 init --reinstall
```

### 权限问题
- 确保设备已开启 USB 调试
- 确保设备已授权 PC 的 ADB 连接
- 某些操作需要无障碍服务权限

## 高级配置

### 指定设备

如果连接多个设备，可以指定设备序列号：

```python
# 修改 server.py
node = AndroidNode(device_serial="XXXXXX")
```

### 自定义端口

```python
# 修改 server.py 中的端口
site = web.TCPSite(runner, "0.0.0.0", 8765)  # HTTP
websockets.serve(..., "0.0.0.0", 8766)       # WebSocket
```

## 安全建议

- 仅在可信网络中使用
- 生产环境建议添加认证机制
- 限制访问 IP 范围

## 性能优化

- 使用 WiFi 连接可以提高稳定性
- 截图操作较慢，建议按需使用
- UI Tree 获取较耗时，建议缓存结果
