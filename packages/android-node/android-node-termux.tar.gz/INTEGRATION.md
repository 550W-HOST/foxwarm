# Android Node 集成指南

## 如何在 Alphabot 中启用 Android Node

### 1. 启动 Android Node Server

在 Android 设备或连接的 PC 上：

```bash
cd packages/android-node
python server.py
```

服务会监听：
- HTTP: `http://0.0.0.0:8765`
- WebSocket: `ws://0.0.0.0:8766`

### 2. 配置 Alphabot

在 alphabot 配置中注册 Android Node（待实现配置系统）：

```typescript
// 示例：在 src/nodes.ts 中添加
nodes.register({
  id: 'android',
  type: 'remote',
  url: 'http://<Android设备IP>:8765',
  tools: [
    'android_tap',
    'android_swipe', 
    'android_input',
    'android_screenshot',
    'android_get_ui_tree'
  ]
});
```

### 3. 使用 Android Tools

在 alphabot 中调用 Android 自动化工具：

```typescript
// 点击屏幕坐标
await tools.android_tap({ x: 500, y: 500 });

// 点击 UI 元素
await tools.android_tap({ text: "确定" });
await tools.android_tap({ resourceId: "com.example:id/button" });

// 滑动手势
await tools.android_swipe({ 
  fx: 500, fy: 1000, 
  tx: 500, ty: 500, 
  duration: 0.3 
});

// 输入文本
await tools.android_input({ text: "Hello Android" });

// 截图
await tools.android_screenshot({ path: "/tmp/screen.png" });

// 获取 UI 树
const result = await tools.android_get_ui_tree({});
console.log(result.xml);
```

### 4. 工具定义（待添加到 src/tools.ts）

```typescript
{
  name: 'android_tap',
  description: 'Tap on Android screen at coordinates or on UI element',
  parameters: {
    type: 'object',
    properties: {
      x: { type: 'number', description: 'X coordinate' },
      y: { type: 'number', description: 'Y coordinate' },
      text: { type: 'string', description: 'UI element text' },
      resourceId: { type: 'string', description: 'UI element resource ID' }
    }
  }
},
{
  name: 'android_swipe',
  description: 'Swipe gesture on Android screen',
  parameters: {
    type: 'object',
    properties: {
      fx: { type: 'number', description: 'From X' },
      fy: { type: 'number', description: 'From Y' },
      tx: { type: 'number', description: 'To X' },
      ty: { type: 'number', description: 'To Y' },
      duration: { type: 'number', description: 'Duration in seconds', default: 0.5 }
    },
    required: ['fx', 'fy', 'tx', 'ty']
  }
},
{
  name: 'android_input',
  description: 'Input text on Android device',
  parameters: {
    type: 'object',
    properties: {
      text: { type: 'string', description: 'Text to input' }
    },
    required: ['text']
  }
},
{
  name: 'android_screenshot',
  description: 'Capture Android screen screenshot',
  parameters: {
    type: 'object',
    properties: {
      path: { type: 'string', description: 'Output file path', default: '/tmp/screenshot.png' }
    }
  }
},
{
  name: 'android_get_ui_tree',
  description: 'Get Android UI hierarchy XML',
  parameters: {
    type: 'object',
    properties: {}
  }
}
```

## 使用场景示例

### 自动化测试
```
用户: "打开设置应用，找到关于手机，截图"
LLM: 
1. android_tap({ text: "设置" })
2. android_tap({ text: "关于手机" })
3. android_screenshot({ path: "/tmp/about.png" })
```

### UI 自动化
```
用户: "在微信中搜索联系人张三"
LLM:
1. android_tap({ text: "微信" })
2. android_tap({ resourceId: "com.tencent.mm:id/search" })
3. android_input({ text: "张三" })
```

## 注意事项

- Android Node 需要设备开启 USB 调试和无障碍服务
- 首次使用需要运行 `python -m uiautomator2 init`
- 建议在可信网络中使用
- 生产环境建议添加认证机制
