# Android Node for Alphabot

Provides Android automation tools via Accessibility Service and Screenshot permissions.

## Features

- **android_tap**: Tap at coordinates or on UI element
- **android_swipe**: Swipe gesture
- **android_input**: Input text
- **android_screenshot**: Capture screen
- **android_ocr**: OCR text recognition
- **android_get_ui_tree**: Get UI hierarchy

## Requirements

- Android device with USB debugging enabled
- Python 3.8+ (via Termux or QPython)
- uiautomator2
- Tesseract OCR (optional)

## Installation

```bash
pip install -r requirements.txt
python server.py
```

## Architecture

- `server.py`: HTTP/WebSocket server connecting to alphabot
- `tools.py`: Android tools implementation
- `accessibility.py`: Accessibility operations wrapper
- `screenshot.py`: Screenshot functionality
- `ocr.py`: OCR recognition
