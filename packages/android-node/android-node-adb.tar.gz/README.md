# Android Node for Alphabot

Provides Android automation tools via Accessibility Service and Screenshot permissions.

## 🚀 部署方式

### 方式 1: ADB 方式（推荐）⭐

**电脑运行 + ADB 控制手机**

- ✅ 性能更好，更稳定
- ✅ 支持多设备控制
- ✅ 无需在手机上安装额外软件

📖 详见：[ADB_DEPLOYMENT.md](ADB_DEPLOYMENT.md)

### 方式 2: Termux 方式（备选）

**手机端运行**

- ✅ 无需电脑
- ✅ 独立运行
- ⚠️ 需要 Termux 环境

📖 详见：[TERMUX_APK.md](TERMUX_APK.md) 和 [QUICKSTART.md](QUICKSTART.md)

## Features

- **android_tap**: Tap at coordinates or on UI element
- **android_swipe**: Swipe gesture
- **android_input**: Input text
- **android_screenshot**: Capture screen
- **android_ocr**: OCR text recognition
- **android_get_ui_tree**: Get UI hierarchy

## Requirements

- Android device with USB debugging enabled
- Python 3.8+ (via Termux or QPython)
- uiautomator2
- Tesseract OCR (optional)

## Installation

```bash
pip install -r requirements.txt
python server.py
```

## Architecture

- `server.py`: HTTP/WebSocket server connecting to alphabot
- `tools.py`: Android tools implementation
- `accessibility.py`: Accessibility operations wrapper
- `screenshot.py`: Screenshot functionality
- `ocr.py`: OCR recognition
