# Android Node - ADB 方式部署（推荐）

## 📋 概述

**推荐方式：电脑运行 Android Node + ADB 控制手机**

这是 Android Node 的主要使用方式：
- ✅ 电脑端运行 Python server
- ✅ 通过 ADB 连接和控制 Android 设备
- ✅ 无需在手机上安装额外软件
- ✅ 性能更好，更稳定

## 🚀 快速开始

### 1. 前置要求

**电脑端：**
- Python 3.8+
- ADB (Android Debug Bridge)

**Android 设备：**
- Android 5.0+ (API 21+)
- 开启 USB 调试
- 连接到电脑（USB 或 WiFi）

### 2. 安装 ADB

**Linux/Mac:**
```bash
# Ubuntu/Debian
sudo apt install adb

# Mac (Homebrew)
brew install android-platform-tools
```

**Windows:**
下载 Android SDK Platform Tools:
https://developer.android.com/studio/releases/platform-tools

### 3. 连接设备

**USB 连接（推荐）：**
```bash
# 检查设备连接
adb devices

# 应该看到：
# List of devices attached
# XXXXXX    device
```

**WiFi 连接（可选）：**
```bash
# 先通过 USB 连接，然后：
adb tcpip 5555
adb connect <设备IP>:5555

# 验证连接
adb devices
```

### 4. 安装依赖

```bash
cd packages/android-node
pip install -r requirements.txt
```

### 5. 初始化 uiautomator2

```bash
# 首次使用需要初始化（会在设备上安装 ATX-agent）
python -m uiautomator2 init
```

这会在设备上安装必要的服务（ATX-agent），只需执行一次。

### 6. 启动 Android Node

```bash
python server.py
```

服务启动后：
- HTTP: `http://localhost:8765`
- WebSocket: `ws://localhost:8766`

## 🧪 测试

```bash
python test.py
```

## 📱 多设备支持

### 连接指定设备

修改 `server.py`：
```python
# 通过序列号连接
node = AndroidNode(device_serial="XXXXXX")

# 通过 WiFi IP 连接
node = AndroidNode(device_serial="192.168.1.100:5555")
```

### 查看设备序列号

```bash
adb devices -l
```

## 🔧 集成到 Alphabot

在 alphabot 配置中注册 Android Node：

```typescript
// 本地运行（推荐）
nodes.register({
  id: 'android',
  type: 'local',
  url: 'http://localhost:8765'
});

// 远程运行
nodes.register({
  id: 'android',
  type: 'remote',
  url: 'http://<电脑IP>:8765'
});
```

## 🎯 使用场景

### 场景 1: 本地开发测试
```
电脑 ← USB → 手机
     ↑
  Alphabot
```

### 场景 2: 远程控制
```
Alphabot Server ← HTTP → Android Node (电脑) ← ADB → 手机
```

### 场景 3: 多设备控制
```
Android Node (电脑) ← ADB → 手机1
                    ← ADB → 手机2
                    ← ADB → 手机3
```

## 🔍 故障排查

### ADB 连接失败

```bash
# 重启 ADB server
adb kill-server
adb start-server

# 检查设备授权
adb devices
# 如果显示 "unauthorized"，在手机上授权电脑
```

### uiautomator2 初始化失败

```bash
# 重新安装
python -m uiautomator2 init --reinstall

# 检查 ATX-agent 状态
adb shell ps | grep atx
```

### 设备离线

```bash
# USB 连接
adb reconnect

# WiFi 连接
adb connect <设备IP>:5555
```

### 权限问题

某些操作需要无障碍服务权限：
1. 设置 → 无障碍 → ATX → 开启

## ⚡ 性能优化

### USB vs WiFi

- **USB**: 更快，更稳定（推荐）
- **WiFi**: 更灵活，无需线缆

### 截图优化

```python
# 使用 minicap（更快的截图）
python -m uiautomator2 init --minicap
```

## 🔒 安全建议

- 仅在可信网络中使用
- 生产环境建议添加认证
- 限制 server 监听地址（如 127.0.0.1）

## 📊 对比：ADB vs Termux

| 特性 | ADB 方式 | Termux 方式 |
|------|----------|-------------|
| 部署位置 | 电脑 | 手机 |
| 性能 | 更好 | 一般 |
| 稳定性 | 更稳定 | 依赖 Termux |
| 多设备 | 支持 | 单设备 |
| 网络要求 | USB/WiFi | 无 |
| 推荐度 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |

**推荐使用 ADB 方式作为主要方案。**

## 🎓 进阶用法

### 自动重连

```python
# 添加重连逻辑
import time

def connect_with_retry(serial=None, max_retries=3):
    for i in range(max_retries):
        try:
            device = u2.connect(serial)
            logger.info(f"Connected: {device.info}")
            return device
        except Exception as e:
            logger.error(f"Connection failed (attempt {i+1}): {e}")
            time.sleep(2)
    raise Exception("Failed to connect after retries")
```

### 设备监控

```python
# 监控设备状态
device.healthcheck()
```

### 批量操作

```python
# 控制多个设备
devices = [
    u2.connect("device1"),
    u2.connect("device2"),
    u2.connect("device3")
]

for device in devices:
    device.click(500, 500)
```
